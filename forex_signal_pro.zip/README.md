# Forex Signal Pro (Flutter) - Prototype

This repository contains a prototype Flutter app 'Forex Signal Pro' that shows a price chart (line), basic technical signal logic, and fetches news when you provide a NEWSAPI key.

## What this does
- Simple line chart (fl_chart) with mock or AlphaVantage FX daily data (if ALPHAVANTAGE_KEY provided in .env)
- Analysis button that computes a simple technical rule and checks recent news for negative keywords
- GitHub Actions workflow to build APK automatically

## How to get APK via GitHub Actions
1. Create a new GitHub repository and push all files from this project.
2. Add a `.env` file in the repository root (DO NOT commit secrets if you care):

```
NEWSAPI_KEY=your_newsapi_key_here
ALPHAVANTAGE_KEY=your_alpha_vantage_key_here
```

3. In GitHub, go to **Actions** and run the 'Build Android APK' workflow (or push to `main`).
4. After workflow finishes, download `app-debug.apk` from **Artifacts**.

## Notes
- This is a prototype. For production-quality trading app you'd integrate real-time websockets, candlestick charts, indicators, and secure auth.
- If you want, I can help deploy and configure the workflow, or build the APK for you using CI (you need to enable Actions in your repo).
