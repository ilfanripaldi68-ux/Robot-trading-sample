import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");
  runApp(const ForexSignalProApp());
}

class ForexSignalProApp extends StatelessWidget {
  const ForexSignalProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Forex Signal Pro',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String pair = 'EURUSD';
  String signal = 'Tidak ada analisa';
  List<FlSpot> spots = [];
  bool loading = false;
  List<String> news = [];

  @override
  void initState() {
    super.initState();
    _loadMockData();
  }

  void _loadMockData() {
    spots = List.generate(50, (i) => FlSpot(i.toDouble(), 1.05 + (i%10) * 0.0015 * (i%3==0 ? -1 : 1)));
  }

  Future<void> analyze() async {
    setState(() { loading = true; signal = 'Menganalisa...'; });
    final alphaKey = dotenv.env['ALPHAVANTAGE_KEY'] ?? '';
    if (alphaKey.isNotEmpty) {
      try {
        final url = Uri.parse('https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=' + pair.substring(0,3) + '&to_symbol=' + pair.substring(3) + '&apikey=' + alphaKey + '&outputsize=compact');
        final resp = await http.get(url).timeout(const Duration(seconds:10));
        if (resp.statusCode == 200) {
          final js = json.decode(resp.body);
          if (js is Map && js.containsKey('Time Series FX (Daily)')) {
            final series = js['Time Series FX (Daily)'] as Map<String,dynamic>;
            final values = series.values.take(50).toList();
            spots = List.generate(values.length, (i) => FlSpot(i.toDouble(), double.parse(values[i]['4. close'])));
          }
        }
      } catch (e) {
        // ignore, keep mock
      }
    }
    double lastAvg = 0, prevAvg = 0;
    if (spots.length >= 10) {
      lastAvg = spots.sublist(spots.length-5).map((s)=>s.y).reduce((a,b)=>a+b)/5;
      prevAvg = spots.sublist(spots.length-10, spots.length-5).map((s)=>s.y).reduce((a,b)=>a+b)/5;
    }
    String tech = 'WAIT';
    if (lastAvg > prevAvg * 1.0003) tech = 'BUY';
    else if (lastAvg < prevAvg * 0.9997) tech = 'SELL';

    news = [];
    final newsKey = dotenv.env['NEWSAPI_KEY'] ?? '';
    if (newsKey.isNotEmpty) {
      try {
        final q = pair;
        final url = Uri.parse('https://newsapi.org/v2/everything?q=' + q + '&pageSize=5&apiKey=' + newsKey);
        final r = await http.get(url).timeout(const Duration(seconds:10));
        if (r.statusCode == 200) {
          final j = json.decode(r.body);
          if (j['articles'] != null) {
            for (var a in j['articles']) {
              news.add((a['title'] ?? '').toString());
            }
          }
        }
      } catch (e) {
        // ignore
      }
    } else {
      news = ['No NEWSAPI_KEY set. Set .env with NEWSAPI_KEY to fetch real news.'];
    }

    String finalSig = tech;
    if (news.any((t) => t.toLowerCase().contains('risk') || t.toLowerCase().contains('drop') || t.toLowerCase().contains('recession'))) {
      finalSig = 'WAIT (Berita negatif)';
    }

    setState(() {
      signal = 'Sinyal: $finalSig (Teknikal: $tech)';
      loading = false;
    });
  }

  Widget buildChart() {
    if (spots.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 240,
      child: LineChart(LineChartData(
        gridData: FlGridData(show: true),
        borderData: FlBorderData(show: true),
        titlesData: FlTitlesData(show: false),
        lineBarsData: [
          LineChartBarData(spots: spots, isCurved: false, dotData: FlDotData(show:false), barWidth: 2),
        ],
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Forex Signal Pro')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Row(children: [
              Expanded(child: DropdownButtonFormField<String>(
                value: pair,
                items: ['EURUSD','GBPUSD','XAUUSD','USDJPY'].map((p) => DropdownMenuItem(value:p, child: Text(p))).toList(),
                onChanged: (v){ if (v!=null) setState(()=>pair=v); },
                decoration: const InputDecoration(labelText: 'Pair'),
              )),
              const SizedBox(width:8),
              ElevatedButton(onPressed: loading?null:() => analyze(), child: loading? const SizedBox(width:16,height:16,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2)): const Text('Analisa'))
            ]),
            const SizedBox(height:12),
            Card(child: Padding(padding: const EdgeInsets.all(12.0), child: Column(children: [
              Text(signal, style: const TextStyle(fontSize:16,fontWeight: FontWeight.bold)),
              const SizedBox(height:8),
              buildChart(),
            ]))),
            const SizedBox(height:12),
            Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(8.0), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Berita / Sentimen (ringkasan):', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height:8),
              Expanded(child: ListView.builder(itemCount: news.length, itemBuilder: (ctx,i){ return ListTile(title: Text(news[i])); }))
            ]))))
          ],
        ),
      ),
    );
  }
}
